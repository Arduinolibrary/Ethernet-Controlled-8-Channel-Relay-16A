﻿namespace RELAY_MODULE_TEST
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox_dcin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label_access = new System.Windows.Forms.Label();
            this.button_access = new System.Windows.Forms.Button();
            this.textBox_status = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // textBox_dcin
            // 
            this.textBox_dcin.Location = new System.Drawing.Point(267, 38);
            this.textBox_dcin.Name = "textBox_dcin";
            this.textBox_dcin.Size = new System.Drawing.Size(57, 20);
            this.textBox_dcin.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "DC in";
            // 
            // label_access
            // 
            this.label_access.AutoSize = true;
            this.label_access.Location = new System.Drawing.Point(122, 95);
            this.label_access.Name = "label_access";
            this.label_access.Size = new System.Drawing.Size(132, 13);
            this.label_access.TabIndex = 28;
            this.label_access.Text = "Enter password for access";
            // 
            // button_access
            // 
            this.button_access.Location = new System.Drawing.Point(260, 90);
            this.button_access.Name = "button_access";
            this.button_access.Size = new System.Drawing.Size(64, 23);
            this.button_access.TabIndex = 29;
            this.button_access.UseVisualStyleBackColor = true;
            this.button_access.Click += new System.EventHandler(this.button_access_Click);
            // 
            // textBox_status
            // 
            this.textBox_status.Location = new System.Drawing.Point(124, 12);
            this.textBox_status.Name = "textBox_status";
            this.textBox_status.Size = new System.Drawing.Size(200, 20);
            this.textBox_status.TabIndex = 18;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(260, 64);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(64, 20);
            this.numericUpDown1.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(127, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "Relay pulse time (100 ms)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 255);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.button_access);
            this.Controls.Add(this.label_access);
            this.Controls.Add(this.textBox_status);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_dcin);
            this.Name = "Form1";
            this.Text = "ETH008 Test";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox_dcin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_access;
        private System.Windows.Forms.Button button_access;
        private System.Windows.Forms.TextBox textBox_status;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
    }
}

