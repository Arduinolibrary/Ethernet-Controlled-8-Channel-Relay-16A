﻿Class UdpState
    Friend e As Object
    Friend u As Object
End Class
