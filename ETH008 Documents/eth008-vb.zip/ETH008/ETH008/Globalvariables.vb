﻿Public Class Globalvariables
    Public Shared Property IPaddress As String
    Public Shared Property Port As Integer

End Class
