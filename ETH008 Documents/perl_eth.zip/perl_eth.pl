#!/usr/local/bin/perl
use strict;

my $PORT='17494' ;
my $IP='192.168.0.87' ;
my $PASSWORD="password";
my $UNLOCK_TIME = 121;
my $PASSWORD_ENTRY = 121;
my $OUTPUT_ACTIVE = 32;
my $OUTPUT_INACTIVE = 33;
my $GET_OUTPUTS = 36;
my $OUTPUT_NUMBER = 1;
my $PULSE_TIME = 20;
my $response ='' ; 

use IO::Socket::INET;
# auto-flush on socket
$| = 1;

my $socket = new IO::Socket::INET (
    PeerHost => $IP,
    PeerPort => $PORT,
    Proto => 'tcp',
)   or die "cant connect";

$socket->send( pack( "C" ,$UNLOCK_TIME));         # Get unlock time to see if a password is needed
$socket->recv($response,1024);
my $unlock = unpack("C", $response);    
if ($unlock == 255){
  printf "Password not set. \n";
} else {
  
  printf "Sending password... \n";
  my $pass = pack("C",$PASSWORD_ENTRY);           # Pack up the send password command and add the password to the end
  $pass .= $PASSWORD;                   
  $socket->send($pass);
  $socket->recv($response,1024);
  $unlock = unpack("C", $response);               # Check if password was accepted
  if ($unlock == 1){
    printf "Password accepted!\n";
  } else {
    printf "Password incorrect.\n";
    exit;
  }
}

$socket->send( pack( "C" ,$GET_OUTPUTS));
$socket->recv($response,1024);
my $outs = unpack("C", $response);
if (($outs && (1 << ($OUTPUT_NUMBER - 1)))){
  printf "Setting output " . $OUTPUT_NUMBER . " inactive.\n";
  $socket->send( pack( "CCC" ,$OUTPUT_INACTIVE,$OUTPUT_NUMBER,$PULSE_TIME));
} else {
  printf "Setting output " . $OUTPUT_NUMBER . " active.\n";
  $socket->send( pack( "CCC" ,$OUTPUT_ACTIVE,$OUTPUT_NUMBER,$PULSE_TIME));
}
$socket->recv($response,1024);

shutdown($socket, 1);
$socket->close();