﻿Public Class custom_ip

    Private Sub custom_ip_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NumericUpDown1.Value = Globalvariables.Port
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub textBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress, TextBox4.KeyPress, TextBox3.KeyPress, TextBox2.KeyPress
        Select Case (e.KeyChar.ToString())
            Case "0"
            Case "1"
            Case "2"
            Case "3"
            Case "4"
            Case "5"
            Case "6"
            Case "7"
            Case "8"
            Case "9"
            Case "\b" 'delete  
            Case Else
                e.Handled = True
        End Select

    End Sub

    Private Sub custom_ip_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Globalvariables.Port = NumericUpDown1.Value
        Globalvariables.IPaddress = TextBox1.Text + "." + TextBox2.Text + "." + TextBox3.Text + "." + TextBox4.Text
    End Sub
End Class