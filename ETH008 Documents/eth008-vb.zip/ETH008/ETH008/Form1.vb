﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Imports System.Threading

Public Class ETH008

    Public Const NUMBEROFRELAYS = 8
    Public Shared messageReceived As Boolean = False

    Dim buttons(NUMBEROFRELAYS) As Button

    Dim SerBuf(10) As Byte                          'a global accessable array for data to be buffered for the COMX port
    Dim relay_states As UInteger
    Dim selected_port As String
    Dim module_version As Byte
    Dim device_found As Boolean = False
    Dim password_protection_on As Byte = 0

    Dim my_ipendpoint As New IPEndPoint(IPAddress.Any, 30)
    Dim my_udpClient As New UdpClient(my_ipendpoint)
    Dim my_udpstate As New UdpState()

    Dim receiveString() As String
    Dim responses As Integer = 0
    Dim tcpClient As TcpClient
    Dim ns As NetworkStream

    Enum commands
        GET_VER = &H10
        DIG_ACTIVE = &H20
        DIG_INACTIVE
        DIG_DIRECTION
        DIG_SET_OUTPUTS
        DIG_GET_OUTPUTS
        DIG_GET_INPUTS
        VAR_SET_OUTPUT = &H30
        VAR_GET_OUTPUT
        VAR_GET_INPUT
        GET_SER_NUM = &H77
        GET_VOLTS
        PASSWORD_ENTRY
        GET_UNLOCK_TIME
        LOG_OUT
    End Enum


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim x As Integer
        Dim y As Integer

        x = 20 'initial starting co-ordinates for button array
        y = 20
        For counter As Integer = 0 To NUMBEROFRELAYS - 1 'for loop initialises each button
            buttons(counter) = New Button

            With buttons(counter)
                .Size = New Size(75, 25)
                .Visible = True
                .Location = New Point(x, y)
                .Text = "Relay " + (counter + 1).ToString
                .Name = "Relay " + (counter + 1).ToString
                'any other property
            End With
            y += 30 ' move down screen 30 for each button
            If ((y + 80) > Me.Size.Height) Then 'if we are near the bottom of the screen then move over a column and start at the top again
                y = 20
                x += 80
            End If
            AddHandler buttons(counter).Click, AddressOf button_relay_Click
        Next

        Me.Controls.AddRange(buttons)

        ComboBoxPortSelect.Items.Add("Custom IP address")
        'conduct a udp scan to see if there is any of our boards on the network, results are picked up asynchronously in ReceiveCallback (non blocking while waiting)
        my_udpClient.EnableBroadcast = True
        my_udpClient.MulticastLoopback = False
        my_udpstate.e = my_ipendpoint
        my_udpstate.u = my_udpClient
        my_udpClient.BeginReceive(New AsyncCallback(AddressOf ReceiveCallback), my_udpstate)
        Dim sendBytes() As Byte = Encoding.ASCII.GetBytes("Discovery: Who is out there?")
        my_udpClient.BeginSend(sendBytes, sendBytes.Length, New IPEndPoint(System.Net.IPAddress.Parse("255.255.255.255"), 30303), Nothing, my_udpClient)
        Globalvariables.Port = 17494
        Globalvariables.IPaddress = "192.168.0.200"
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim temp As UInteger
        Dim x As Byte

        If (device_found = True) Then
            'set all the background colours according to the relay states
            SerBuf(0) = commands.DIG_GET_OUTPUTS
            transmit(1)
            receive(1)
            relay_states = SerBuf(0)

            For x = 0 To NUMBEROFRELAYS - 1 Step 1
                If ((relay_states And (1 << x)) = (1 << x)) Then
                    buttons(x).BackColor = Color.Red
                Else : buttons(x).BackColor = Color.Empty
                End If
            Next
            'dc input voltage
            SerBuf(0) = commands.GET_VOLTS
            transmit(1)
            receive(1)
            TextBoxDcIn.Text = SerBuf(0) / 10.ToString()
        End If
    End Sub

    Private Sub button_relay_Click(sender As Object, e As EventArgs)
        Dim x As Integer
        x = Convert.ToInt16(sender.ToString().Substring(41))   'extract and convert the relay number to an integer from the sender string

        If (device_found = True) Then
            If (password_protection_on = 0) Then
                If (buttons(x - 1).BackColor = Color.Red) Then
                    SerBuf(0) = commands.DIG_INACTIVE
                Else : SerBuf(0) = commands.DIG_ACTIVE
                End If
                SerBuf(1) = x
                SerBuf(2) = NumericUpDown_pulsetime.Value
                transmit(3)
                receive(1)
            Else : MessageBox.Show("Can't change state\rPassword required", "Error")
            End If
        Else : MessageBox.Show("No board connected", "Error")
        End If
    End Sub

    Private Sub transmit(write_bytes As Byte)
        If (device_found = True) Then
            Try
                ns.WriteTimeout = 100
                ns.Write(SerBuf, 0, write_bytes)
                ns.Flush()

            Catch
                device_found = False
                MessageBox.Show("write fail")

            End Try
        End If
    End Sub


    Private Sub receive(read_bytes As Byte)

        Dim x As Byte
        If (device_found = True) Then
            For x = 1 To read_bytes Step 1     ' this will call the read function for the passed number times, 
                ' this way it ensures each byte has been correctly recieved while
                Try                                ' still using timeouts
                    ns.Read(SerBuf, x - 1, 1)     ' retrieves 1 byte at a time and places in SerBuf at position x

                Catch
                    ' timeout or other error occured, set lost comms indicator
                    device_found = False
                    MessageBox.Show("read fail")
                End Try
            Next
        End If
    End Sub


    Private Sub ComboBoxPortSelect_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxPortSelect.SelectedIndexChanged

        Dim connected As Byte = 0
        Dim success As New Boolean
        Dim selected_ipaddress As String = ""

        If (ComboBoxPortSelect.Text = "Custom IP") Then
            custom_ip.ShowDialog()
            selected_ipaddress = Globalvariables.IPaddress
        Else
            selected_ipaddress = ComboBoxPortSelect.Text.Substring(0, ComboBoxPortSelect.Text.IndexOf(" ")) 'extracts ip address segment from combobox text
            port_entry.ShowDialog()
        End If

        tcpClient = New TcpClient() 'initialise new tcp client, required here because connection failure disposes of the object
        Try
            Dim result As IAsyncResult = tcpClient.BeginConnect(selected_ipaddress, Globalvariables.Port, Nothing, Nothing)
            success = result.AsyncWaitHandle.WaitOne(2000, True)

            If (success = 0) Then
                connected = 0
                tcpClient.Close()
                MessageBox.Show("Failed to connect")
            Else : connected = 1
            End If

            If (connected = 1) Then
                device_found = True
                ns = tcpClient.GetStream()
                ns.ReadTimeout = 1000
                SerBuf(0) = commands.GET_VER ' get version command for ETH008, returns software version
                transmit(1)
                receive(3)
                module_version = SerBuf(2) '  //print the software version on screen
                TextBoxVer.Text = module_version.ToString()
            End If

        Catch
            device_found = False
            If (selected_port = "Custom IP") Then
                MessageBox.Show("Unable to connect to module at " + Globalvariables.IPaddress)
            Else : MessageBox.Show("Unable to connect to module at " + selected_port)
            End If
        End Try

        Return
    End Sub

    'combobox for ports has to be modified on the primary thread
    Private Sub add_discovery()
        Try
            ComboBoxPortSelect.Items.Clear()
            ComboBoxPortSelect.Items.AddRange(receiveString)
            ComboBoxPortSelect.Items.Add("Custom IP")
        Catch
        End Try

    End Sub

    'asynchronus recieve of ip addresses
    Public Sub ReceiveCallback(ByVal ar As IAsyncResult)
        Dim board_type As String
        Dim receiveBytes() As Byte = my_udpClient.EndReceive(ar, my_udpstate.e)

        board_type = Encoding.ASCII.GetString(receiveBytes)
        board_type = board_type.Substring(0, board_type.IndexOf(" ")) ' rip out board type from frame
        If (board_type = "ETH008") Then
            ReDim receiveString(responses)
            receiveString(responses) = my_udpstate.e.Address.ToString() + "     " + board_type
            responses = responses + 1
            Me.BeginInvoke(New MethodInvoker(AddressOf add_discovery))
        Else
        End If

        my_udpstate.u.BeginReceive(New AsyncCallback(AddressOf ReceiveCallback), my_udpstate.u)
    End Sub
End Class
