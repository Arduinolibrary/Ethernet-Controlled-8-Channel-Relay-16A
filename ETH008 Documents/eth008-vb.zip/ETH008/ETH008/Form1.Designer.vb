﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ETH008
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ComboBoxPortSelect = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxVer = New System.Windows.Forms.TextBox()
        Me.TextBoxDcIn = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.NumericUpDown_pulsetime = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.NumericUpDown_pulsetime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ComboBoxPortSelect
        '
        Me.ComboBoxPortSelect.FormattingEnabled = True
        Me.ComboBoxPortSelect.Location = New System.Drawing.Point(135, 21)
        Me.ComboBoxPortSelect.Name = "ComboBoxPortSelect"
        Me.ComboBoxPortSelect.Size = New System.Drawing.Size(211, 21)
        Me.ComboBoxPortSelect.Sorted = True
        Me.ComboBoxPortSelect.TabIndex = 12
        Me.ComboBoxPortSelect.Text = "Select Comm Port"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(103, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Port"
        '
        'TextBoxVer
        '
        Me.TextBoxVer.Location = New System.Drawing.Point(301, 52)
        Me.TextBoxVer.Name = "TextBoxVer"
        Me.TextBoxVer.Size = New System.Drawing.Size(45, 20)
        Me.TextBoxVer.TabIndex = 14
        '
        'TextBoxDcIn
        '
        Me.TextBoxDcIn.Location = New System.Drawing.Point(301, 81)
        Me.TextBoxDcIn.Name = "TextBoxDcIn"
        Me.TextBoxDcIn.Size = New System.Drawing.Size(45, 20)
        Me.TextBoxDcIn.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(244, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Version"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(253, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "DC In"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'NumericUpDown_pulsetime
        '
        Me.NumericUpDown_pulsetime.Location = New System.Drawing.Point(301, 107)
        Me.NumericUpDown_pulsetime.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.NumericUpDown_pulsetime.Name = "NumericUpDown_pulsetime"
        Me.NumericUpDown_pulsetime.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown_pulsetime.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(231, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Pulse time"
        '
        'ETH008
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(366, 277)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.NumericUpDown_pulsetime)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBoxDcIn)
        Me.Controls.Add(Me.TextBoxVer)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBoxPortSelect)
        Me.Name = "ETH008"
        Me.Text = "ETH008"
        CType(Me.NumericUpDown_pulsetime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxVer As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxDcIn As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Public WithEvents ComboBoxPortSelect As System.Windows.Forms.ComboBox
    Friend WithEvents NumericUpDown_pulsetime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer

End Class
