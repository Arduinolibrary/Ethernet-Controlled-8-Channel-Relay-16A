﻿Public Class port_entry

    Private Sub port_entry_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NumericUpDown1.Value = Globalvariables.Port
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Globalvariables.Port = NumericUpDown1.Value
        Me.Close()
    End Sub
End Class