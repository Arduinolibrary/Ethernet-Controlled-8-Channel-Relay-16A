﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;          // added to include serial ports
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Management;
using System.Threading;

namespace RELAY_MODULE_TEST
{
    public partial class Form1 : Form
    {
        public delegate void AsyncCallback(IAsyncResult ar);
        public delegate void AddTolstDiscoveredDevices(object o);

        enum commands
        {
            GET_VER = 0x10,
            DIG_ACTIVE = 0x20, DIG_INACTIVE, DIG_DIRECTION, DIG_SET_OUTPUTS, DIG_GET_OUTPUTS, DIG_GET_INPUTS,
            VAR_SET_OUTPUT = 0x30, VAR_GET_OUTPUT, VAR_GET_INPUT,

            GET_SER_NUM = 0x77, GET_VOLTS, PASSWORD_ENTRY, GET_UNLOCK_TIME, LOG_OUT,
        };

        static SerialPort USB_PORT;
        bool device_found = false;
        byte[] SerBuf = new byte[70];
        NetworkStream ns;
        TcpClient server;
        private UdpState GlobalUDP;
        string selected_port;
        byte module_version;
        MainMenu MyMenu;
        byte password_protection_on = 0;
        Button[] RelayButtons = new Button[8];

        struct UdpState
        {
            public System.Net.IPEndPoint EP;
            public System.Net.Sockets.UdpClient UDPClient;
        }

        public Form1()
        {
            int vertical,horizontal;

            InitializeComponent();
            MyMenu = new MainMenu();

            vertical = 5;
            horizontal = 3;
            for (int i = 0; i < RelayButtons.Length; i++)   //add all the relay buttons to the form as an array, this allows the buttons to be accessed easily within loops
            {
                RelayButtons[i] = new Button();
                RelayButtons[i].Size = new Size(74, 23);
                RelayButtons[i].Location = new Point(horizontal, vertical);
                vertical += 27;
                if (vertical + 80 > this.Height) //moves over a column when we have reached the bottom of the form (+80 due to top bar)
                {
                    horizontal += 80;
                    vertical = 5;
                }
                RelayButtons[i].Text = "RELAY " + (i+1).ToString();
                this.Controls.Add(RelayButtons[i]);
                RelayButtons[i].Click += new EventHandler(button_relay_Click);
            }
        }

        public void AddDiscoveryEntry(object o)
        {
            string[] temp;
            temp = ((string)(o)).Split('\n');
            temp[1] = temp[1].TrimEnd(' ');
            if(temp[1] == "ETH008")
            {
                MenuItem newMenuItem2 = new MenuItem();
                newMenuItem2.Text = temp[0] + "," + temp[1];
                newMenuItem2.Click += new EventHandler(changeport);
                this.BeginInvoke(new MethodInvoker(delegate()
                {
                    MyMenu.MenuItems[0].MenuItems[0].MenuItems.Add(newMenuItem2);
                }
                ));
            }
        }

        public void ReceiveCallback(IAsyncResult ar)
        {
            UdpState MyUDP = (UdpState)ar.AsyncState;

            // Obtain the UDP message body and convert it to a string, with remote IP address attached as well
            string ReceiveString = Encoding.ASCII.GetString(MyUDP.UDPClient.EndReceive(ar, ref MyUDP.EP));
            ReceiveString = MyUDP.EP.Address.ToString() + "\n" + ReceiveString.Replace("\r\n", "\n");

            // Configure the UdpClient class to accept more messages, if they arrive
            MyUDP.UDPClient.BeginReceive(ReceiveCallback, MyUDP);
            // Write the received UDP message text to the listbox in a thread-safe manner
            //lstDiscoveredDevices.Invoke(new AddTolstDiscoveredDevices(AddDiscoveryEntry), ReceiveString);
            AddDiscoveryEntry(ReceiveString);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            byte x;
            int temp;

            if (device_found == true)
            {
                textBox_status.Text = "ETH008 v" + module_version.ToString() + " found";            

                SerBuf[0] = (byte)commands.GET_VOLTS; ;
                transmit(1);
                receive(1);
                textBox_dcin.Text = string.Format("{0}v", (float)SerBuf[0] / 10);

                SerBuf[0] = (byte)commands.GET_UNLOCK_TIME;
                transmit(1);
                receive(1);
                if (SerBuf[0] != 255)
                {
                    if (SerBuf[0] == 0)
                    {
                        button_access.Text = "Password";
                        label_access.Visible = true;
                        password_protection_on = 1;
                    }
                    else
                    {
                        button_access.Text = SerBuf[0].ToString();
                        label_access.Visible = false;
                        password_protection_on = 0;
                    }
                    button_access.Visible = true;

                }
                else
                {
                    label_access.Visible = false;
                    button_access.Visible = false;
                    password_protection_on = 0;
                }

                SerBuf[0] = (byte)commands.DIG_GET_OUTPUTS;      // get states command
                transmit(1);
                receive(1);

                temp = SerBuf[2] << 16;
                temp += SerBuf[1] << 8;
                temp += SerBuf[0];
                for (x = 0; x < RelayButtons.Length; x++)
                {
                    if((temp & (0x01<<x)) > 0) RelayButtons[x].BackColor = Color.Red;
                    else RelayButtons[x].BackColor = Color.White;
                }
            }
        }

        private void changeport(object sender, EventArgs e)  //opens a comport or network stream corresponding with combobox selection
        {
            password_protection_on = 0;
            try
            {
                if(device_found == true)
                {
                    SerBuf[0] = (byte)commands.LOG_OUT;
                    transmit(1);
                    receive(1);
                }
                ns.Close();
                server.Close();
            }
            catch { }
            selected_port = sender.ToString().Substring(53);
            device_found = false;
            if (selected_port == "Custom IP")
            {
                GlobalClass.ip_input = 1;
                Form2 secondForm = new Form2();
                secondForm.ShowDialog();
                if (GlobalClass.ipaddress != "0.0.0.0") open_ethernet_connection();
            }

            else // its an ethernet device selected
            {
                GlobalClass.ip_input = 0;
                Form2 secondForm = new Form2();
                secondForm.ShowDialog();
                open_ethernet_connection();
            }
        }

        private void open_ethernet_connection()
        {
            byte connected = 0;

            TcpClient client = new TcpClient();
            try
            {
                if (selected_port == "Custom IP")
                {
                    IAsyncResult result = client.BeginConnect(GlobalClass.ipaddress, GlobalClass.port, null, null);

                    bool success = result.AsyncWaitHandle.WaitOne(2000, true);

                    if (!success)
                    {
                        connected = 0;
                        client.Close();
                        MessageBox.Show("Failed to connect");
                    }
                    else connected = 1;
                }
                else
                {
                    IAsyncResult result = client.BeginConnect(selected_port.Substring(0, selected_port.IndexOf(",")), GlobalClass.port, null, null);

                    bool success = result.AsyncWaitHandle.WaitOne(2000, true);

                    if (!success)
                    {
                        connected = 0;
                        client.Close();
                        MessageBox.Show("Failed to connect");
                    }
                    else connected = 1;
                }
                if (connected == 1)
                {
                    ns = client.GetStream();
                    ns.ReadTimeout = 5000;
                    ns.WriteTimeout = 5000;
                    SerBuf[0] = (byte)commands.GET_VER;     // get version command for ETH RLY16/02, returns software version
                    transmit(1);
                    receive(3);
                    MyMenu.MenuItems[1].Visible = true;
                    module_version = SerBuf[2];  //print the software version on screen
                    device_found = true;
                }
            }
            catch (SocketException)
            {
                if (selected_port == "Custom IP")
                {
                    MessageBox.Show("Unable to connect to module at " + GlobalClass.ipaddress);
                }
                else MessageBox.Show("Unable to connect to module at " + selected_port);
                return;
            } 
        }

        private void transmit(byte write_bytes)
        {
            try
            {
                ns.Write(SerBuf, 0, write_bytes);
                ns.Flush();
            }
            catch
            {
                device_found = false;
                MessageBox.Show("write fail");
            }
        }

        private void receive(byte read_bytes)
        {
            byte x;

            for (x = 0; x < read_bytes; x++)       // this will call the read function for the passed number times, 
            {                                      // this way it ensures each byte has been correctly recieved while
                try                                // still using timeouts
                {
                    ns.Read(SerBuf, x, 1);     // retrieves 1 byte at a time and places in SerBuf at position x
                }
                catch (Exception)                   // timeout or other error occured, set lost comms indicator
                {
                    device_found = false;
                    MessageBox.Show("read fail");
                }
            }
        }

        private void button_relay_Click(object sender, EventArgs e)
        {
            int x;
            x = Convert.ToInt16(sender.ToString().Substring(41));   //extract and convert the relay number to an integer from the sender string

            if(device_found == true)
            {
                if (password_protection_on == 0){
                    if (RelayButtons[x-1].BackColor == Color.Red) SerBuf[0] = (byte)commands.DIG_INACTIVE;
                    else SerBuf[0] = (byte)commands.DIG_ACTIVE;
                    SerBuf[1] = (byte) x;
                    SerBuf[2] = (byte) numericUpDown1.Value;
                    transmit(3);
                    receive(1);
                }
                else MessageBox.Show("Can't change state\rPassword required", "Error");
            }
        }

        private void allon_Click(object sender, EventArgs e)
        {
            if(device_found == true)
            {
                if (password_protection_on == 0)
                {
                    SerBuf[0] = (byte)commands.DIG_SET_OUTPUTS;
                    SerBuf[1] = 0xff;
                    SerBuf[2] = 0xff;
                    SerBuf[3] = 0xff;
                    transmit(4);
                    receive(1);
                }
                else MessageBox.Show("Can't change state\rPassword required", "Error");
            }
        }

        private void alloff_Click(object sender, EventArgs e)
        {
            if (device_found == true)
            {
                if (password_protection_on == 0)
                {
                    SerBuf[0] = (byte)commands.DIG_SET_OUTPUTS;
                    SerBuf[1] = 0x00;
                    SerBuf[2] = 0x00;
                    SerBuf[3] = 0x00;
                    transmit(4);
                    receive(1);
                }
                else MessageBox.Show("Can't change state\rPassword required", "Error");
            }
        }

        private void pat1_Click(object sender, EventArgs e)
        {
            if (device_found == true)
            {
                if (password_protection_on == 0)
                {
                    SerBuf[0] = (byte)commands.DIG_SET_OUTPUTS;
                    SerBuf[1] = 0x55;
                    SerBuf[2] = 0x55;
                    SerBuf[3] = 0x55;
                    transmit(4);
                    receive(1);
                }
                else MessageBox.Show("Can't change state\rPassword required", "Error");
            }
        }

        private void pat2_Click(object sender, EventArgs e)
        {
            if (device_found == true)
            {
                if (password_protection_on == 0)
                {
                    SerBuf[0] = (byte)commands.DIG_SET_OUTPUTS;
                    SerBuf[1] = 0xAA;
                    SerBuf[2] = 0xAA;
                    SerBuf[3] = 0xAA;
                    transmit(4);
                    receive(1);
                }
                else MessageBox.Show("Can't change state\rPassword required", "Error");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) // attempt to close any open network stream on form closure
        {
            try
            {
                SerBuf[0] = (byte)commands.LOG_OUT;
                transmit(1);
                receive(1);
                ns.Close();
                ns.Dispose();
                server.Close();
            }
            catch { }
        }

        private void button_access_Click(object sender, EventArgs e)
        {
            byte x;
            Form3 thirdForm = new Form3();
            thirdForm.ShowDialog();
            if (GlobalClass.password != "")
            {
                SerBuf[0] = (byte)commands.PASSWORD_ENTRY;
                for (x = 0; x < GlobalClass.password.Length; x++)
                {
                    SerBuf[x + 1] = (byte)GlobalClass.password[x];
                          
                }
                transmit((byte)(GlobalClass.password.Length + 1));  
                receive(1);
            }           
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            MenuItem m1 = new MenuItem("Setup");
            MenuItem setupm1 = new MenuItem("Set Comport");
            m1.MenuItems.Add(setupm1);

            MenuItem newMenuItem3 = new MenuItem();
            newMenuItem3.Text = "Custom IP";
            setupm1.MenuItems.Add(newMenuItem3);
            newMenuItem3.Click += new EventHandler(changeport);

            MenuItem m2 = new MenuItem("Relay set");
            MenuItem relaym1 = new MenuItem("All on");
            m2.MenuItems.Add(relaym1);
            MenuItem relaym2 = new MenuItem("All off");
            m2.MenuItems.Add(relaym2);
            MenuItem relaym3 = new MenuItem("10101010");
            m2.MenuItems.Add(relaym3);
            MenuItem relaym4 = new MenuItem("01010101");
            m2.MenuItems.Add(relaym4);

            Menu = MyMenu;
            MyMenu.MenuItems.Add(m1);
            MyMenu.MenuItems.Add(m2);
 
            try
            {
                GlobalUDP.UDPClient = new UdpClient();
                GlobalUDP.EP = new System.Net.IPEndPoint(System.Net.IPAddress.Parse("255.255.255.255"), 30303);
                System.Net.IPEndPoint BindEP = new System.Net.IPEndPoint(System.Net.IPAddress.Any, 30303);
                byte[] DiscoverMsg = Encoding.ASCII.GetBytes("Discovery: Who is out there?");

                // Set the local UDP port to listen on
                GlobalUDP.UDPClient.Client.Bind(BindEP);

                // Enable the transmission of broadcast packets without having them be received by ourself
                GlobalUDP.UDPClient.EnableBroadcast = true;
                GlobalUDP.UDPClient.MulticastLoopback = false;

                // Configure ourself to receive discovery responses
                GlobalUDP.UDPClient.BeginReceive(ReceiveCallback, GlobalUDP);

                // Transmit the discovery request message
                GlobalUDP.UDPClient.Send(DiscoverMsg, DiscoverMsg.Length, new System.Net.IPEndPoint(System.Net.IPAddress.Parse("255.255.255.255"), 30303));
            }
            catch { }
            relaym1.Click += new EventHandler(allon_Click);
            relaym2.Click += new EventHandler(alloff_Click);
            relaym3.Click += new EventHandler(pat1_Click);
            relaym4.Click += new EventHandler(pat2_Click);
        }
    }
}
